package com.co.udea.mintic.chameleonApp.entities;

import javax.persistence.Table;

@Table(name= "enum_role_name")
public enum Enum_RoleName {
    ADMIN,
    OPERARIO
    }
