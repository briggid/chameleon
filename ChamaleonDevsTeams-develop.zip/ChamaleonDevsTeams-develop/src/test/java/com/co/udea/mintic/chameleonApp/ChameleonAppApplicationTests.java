package com.co.udea.mintic.chameleonApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChameleonAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
